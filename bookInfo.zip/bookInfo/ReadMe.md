# Project Readme

## Overview

This project is built using Spring Boot 3 and Java 17 and Guava for caching.
The main functionality of the project is providing the latest information of books from New York Times.
For this purpose it involves a scheduler that retrieve the latest data from the New York Times APIs every 3 minutes
(based on the project specifications) and store data in the cache(the cached data will expire after 3 minutes).

The process of refreshing data involves two main steps:

1. `Initial API Call`: The application first calls the `/names.json` api to retrieve the names of all the bestseller lists.
2. `Data Retrieval`: Following the initial call, the application then calls the `/lists.json` api for each bestseller list. This step can be tricky due to certain limitations and requirements:
    - To manage the limitations of the New York Times API calls (which only allows 5 requests per minute and 500 requests per day),
      the application handles the `RateLimitExceed` exception gracefully. If the application get this exception, the current thread will wait for 12 seconds (it's configurable in `application.yml` file) before retry.
      Also, to have better performance, application is using `Thread pool` in calling New York Times APIs. (The configuration of Thread pool is in `application.yml` file)
    - The New York Times API supports pagination through an offset parameter. Therefore, if the size of the book information list is greater than the specified offset of 20, the application will handle pagination to retrieve data for all the books.


## Setup and Installation

### Prerequisites
- Java 17
- Maven
- Spring Boot 3
 

### Installation
- Clone the repository to your local machine.
- Run the application using the provided Maven command.
  - run application: `mvn spring-boot:run`
  - run test: `mvn test`

## How to Use the Endpoint

To use the endpoint, send a GET request to: `http://localhost:8080/me/books/list?author=[author_name]&year=[]`,
for example: `http://localhost:8080/me/books/list?author=Stephen&year=2023`

In this service `year` parameter is optional and also you can pass multiple years seperated with comma.
for example: `http://localhost:8080/me/books/list?author=Stephen&year=2023,2021`


You can check api documentation of service through this path: `http://localhost:8080/swagger-ui/index.html`