package com.ing.book.config;

import com.ing.book.domain.Book;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.concurrent.TimeUnit;
import java.util.HashSet;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class CacheStoreTest {

    private CacheStore cacheStore;

    @BeforeEach
    public void setUp() {
        cacheStore = new CacheStore(1, TimeUnit.SECONDS);
        HashSet<Book> books = new HashSet<>();
        books.add(new Book("book name", "author", "publisher name" , 2023));
        cacheStore.addToCache("key", books);
    }

    @Test
    public void testAddToCache() {
        Book book = new Book("book name", "author", "publisher name" , 2023);
        HashSet<Book> retrievedBooks = cacheStore.getFromCache("key");
        assertNotNull(retrievedBooks);
        assertEquals(1, retrievedBooks.size());
        assertTrue(retrievedBooks.contains(book));
    }

    @Test
    public void testGetFromCache() {
        assertNull(cacheStore.getFromCache("nonExistentKey"));
        assertNotNull(cacheStore.getFromCache("key"));
    }

    @Test
    public void testIsExpired() throws InterruptedException {
        assertFalse(cacheStore.isExpired("key"));
        Thread.sleep(2000); // Wait for cache to expire
        assertTrue(cacheStore.isExpired("key"));
    }

}