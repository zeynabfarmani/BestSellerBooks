package com.ing.book.service.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.book.config.CacheStore;
import com.ing.book.domain.BestSellerListName;
import com.ing.book.service.client.impl.NYTBookServiceImpl;
import com.ing.book.utils.JsonConverter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import com.ing.book.domain.BestSellerBooks;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doReturn;



@ExtendWith(MockitoExtension.class)
class CacheUtilsTest {

    @Mock
    private NYTBookServiceImpl nytBookService;
//    @InjectMocks
    private CacheUtils cacheUtils;

    private final Executor nytThreadPool = new ThreadPoolTaskExecutor();
    JsonConverter<BestSellerBooks> jsonToBestSellerBookConverter = new JsonConverter<>(BestSellerBooks.class, new ObjectMapper());
    JsonConverter<BestSellerListName> jsonToBestSellerListNameConverter = new JsonConverter<>(BestSellerListName.class, new ObjectMapper());

    @BeforeEach
    void setUp() {
//        MockitoAnnotations.openMocks(this);
        CacheStore booksInfoByAuthorCache = new CacheStore(20, TimeUnit.SECONDS);
        ((ThreadPoolTaskExecutor) nytThreadPool).initialize();
        cacheUtils = new CacheUtils(nytBookService, nytThreadPool, booksInfoByAuthorCache);
    }

    @Test
    void retrieveDataFromNYTsApi_happyFlow() throws InterruptedException {

        String nameListFilePath = "/json/names_list.json";
        BestSellerListName nameListExpectedResult = jsonToBestSellerListNameConverter.getJsonObject(nameListFilePath);
        doReturn(nameListExpectedResult).when(nytBookService).getBestSellerNames();

        String bookListFilePath = "/json/info_5books_for_two_author.json";
        BestSellerBooks bookListExpectedResult = jsonToBestSellerBookConverter.getJsonObject(bookListFilePath);
        doReturn(bookListExpectedResult).when(nytBookService).getBooksDetailsByListNameFromNYT("paperback-advice");

        cacheUtils.retrieveDataFromNYTsApi();
        Thread.sleep(2000);
        assertEquals(3, cacheUtils.getBooksInfoByAuthorCache().getFromCache("Nick Tate").size());
    }

//    @Test
//    void retrieveDataFromNYTsApi_exceptionFlow() {
//
//        String nameListFilePath = "/names_list.json";
//        BestSellerListName nameListExpectedResult = jsonToBestSellerListNameConverter.getJsonObject(nameListFilePath);
//        doReturn(nameListExpectedResult).when(nytBookService).getBestSellerNames();
//        doThrow(new RateLimitExceedException(Constants.RATE_LIMIT_EXCEED)).when(nytBookService).getBooksDetailesByListNameFromNYT("paperback-advice");
//        cacheUtils.retrieveDataFromNYTsApi();
//        verify(cacheUtils, times(1)).sleepForAWhile();
//
//    }

    @Test
    void getBooksDetailsByListName() {

        String path = "/json/info_5books_for_two_author.json";
        BestSellerBooks expectedResult = jsonToBestSellerBookConverter.getJsonObject(path);
        doReturn(expectedResult).when(nytBookService).getBooksDetailsByListNameFromNYT("paperback-advice");
        cacheUtils.getBooksDetailsByListName("paperback-advice");
        assertEquals(2 , cacheUtils.getBooksInfoByAuthorCache().getFromCache("Gary Chapman").size());
        assertEquals(3 , cacheUtils.getBooksInfoByAuthorCache().getFromCache("Nick Tate").size());
    }

    @Test
    void testSleepForAWhile() {
        assertDoesNotThrow(cacheUtils::sleepForAWhile);
    }

}