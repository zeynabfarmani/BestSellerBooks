package com.ing.book.proxy;

import com.ing.book.controller.DTO.BookInfoDTO;
import com.ing.book.controller.DTO.BookListDTO;
import com.ing.book.domain.Book;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;
import com.ing.book.config.CacheStore;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class NYTBookServiceProxyTest {

    private NYTBookServiceProxy nytBookServiceProxy;

    @BeforeEach
    public void setUp() {
        CacheStore cacheStore = new CacheStore(60, TimeUnit.SECONDS);
        HashSet<Book> bookSet1 = new HashSet<>();
        bookSet1.add(new Book("Book1", "Author1", "Publisher1", 2022));
        bookSet1.add(new Book("Book2", "Author1", "Publisher2", 2023));
        cacheStore.addToCache("Author1", bookSet1);
        HashSet<Book> bookSet2 = new HashSet<>();
        bookSet2.add(new Book("Book3", "Author2", "Publisher3", 2022));
        cacheStore.addToCache("Author2", bookSet2);

        nytBookServiceProxy = new NYTBookServiceProxy(cacheStore);
    }


    @Test
    public void getBooksByAuthorAndYearTest() {

        // Test with a list of years
        BookListDTO actualResult1 = nytBookServiceProxy.getBooksByAuthorAndYear("Author1", Arrays.asList(2022, 2023));
        BookListDTO expectedResult1 = new BookListDTO("Author1",Arrays.asList(new BookInfoDTO("Book1" , "Publisher1", 2022),
                new BookInfoDTO("Book2" , "Publisher2", 2023)));
        assertEquals(2, actualResult1.getBookInfoDTOS().size());
        assertEquals(expectedResult1 , actualResult1);

        // Test without a list of years
        BookListDTO actualResult2 = nytBookServiceProxy.getBooksByAuthorAndYear("Author1", Collections.emptyList());
        assertEquals(2, actualResult2.getBookInfoDTOS().size());
        assertEquals(expectedResult1 , actualResult2);

        // Test with non-existing author
        BookListDTO result3 = nytBookServiceProxy.getBooksByAuthorAndYear("Author3", Arrays.asList(2022));
        assertEquals(0, result3.getBookInfoDTOS().size());

        // Test with an invalid year
        BookListDTO result4 = nytBookServiceProxy.getBooksByAuthorAndYear("Author1", Arrays.asList(2021));
        assertEquals(0, result4.getBookInfoDTOS().size());
    }
}
