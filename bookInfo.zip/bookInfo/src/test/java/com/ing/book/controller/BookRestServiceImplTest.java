package com.ing.book.controller;

import com.ing.book.controller.DTO.BookInfoDTO;
import com.ing.book.controller.DTO.BookListDTO;
import com.ing.book.proxy.NYTBookServiceProxy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
public class BookRestServiceImplTest {
    @Mock
    private NYTBookServiceProxy nytBookService;

    private BookRestServiceImpl restService;

    @BeforeEach
    void setUp() {
        restService = new BookRestServiceImpl(nytBookService);
    }

    @Test
    public void callEndpointWithMultipleYear() {
        BookListDTO expectedResult = new BookListDTO("Author1", Arrays.asList(
                new BookInfoDTO("Book1" , "Publisher1", 2022),
                new BookInfoDTO("Book2" , "Publisher2", 2023)));

        doReturn(expectedResult).when(nytBookService).getBooksByAuthorAndYear("Author1", List.of(2022,2023));

        ResponseEntity<BookListDTO> actualResult = restService.getBooksByAuthorAndYear("Author1","2022,2023");

        assertEquals(expectedResult , actualResult.getBody());
    }

}