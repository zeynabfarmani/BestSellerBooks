package com.ing.book.scheduler;

import com.ing.book.service.core.CacheUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.doThrow;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;

@ExtendWith(OutputCaptureExtension.class)
@ExtendWith(MockitoExtension.class)
public class NYTSchedulerTest {
    private final CacheUtils cacheUtils = Mockito.mock(CacheUtils.class);

    private NYTScheduler nytScheduler;

    @BeforeEach
    public void setup() {
        nytScheduler = new NYTScheduler(cacheUtils);
    }

    @Test
    public void testUpdateCacheData(CapturedOutput output) {
        // Mock the behavior of retrieveDataFromNYTsApi to throw a RuntimeException
        doThrow(new RuntimeException("Error while retrieving data from NYT API"))
                .when(cacheUtils).retrieveDataFromNYTsApi();

        // Call the updateCacheData method
        nytScheduler.updateCacheData();

        Assertions.assertTrue(output.getOut().contains("Error while retrieving data from NYT API"));
    }
}











