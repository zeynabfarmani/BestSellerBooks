package com.ing.book.service.client.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ing.book.domain.BestSellerBooks;
import com.ing.book.domain.BestSellerListName;
import com.ing.book.exception.RateLimitExceedException;
import com.ing.book.utils.Constants;
import com.ing.book.utils.JsonConverter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.system.OutputCaptureExtension;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.MockitoAnnotations.openMocks;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.assertj.core.api.Assertions;
import java.net.URI;
import java.net.URISyntaxException;


@ExtendWith(OutputCaptureExtension.class)
@ExtendWith(MockitoExtension.class)
class NYTBookServiceImplTest {
   @Spy
    private NYTBookServiceImpl nytBookService;
    private ObjectMapper objectMapper;

    JsonConverter<BestSellerBooks> jsonToBestSellerBookConverter = new JsonConverter<>(BestSellerBooks.class, new ObjectMapper());


    @BeforeEach
    public void setup() {
        openMocks(this);
        objectMapper = new ObjectMapper();
    }

    @Test
    void shouldThrowExceptionWhenGotRateLimitException() {
        
        doThrow(new RateLimitExceedException(Constants.RATE_LIMIT_EXCEED))
                .when(nytBookService).callNYTsApi(any());

        assertThrows(RateLimitExceedException.class, () -> {
            nytBookService.getBestSellerNames();
        });
        
    }

    @Test
    void getBestSellerNamesInSuccessfulFlow() throws URISyntaxException, JsonProcessingException {
        String expectedResponseBodyStr = "{\n" +
                "  \"copyright\": \"copy right\",\n" +
                "  \"status\": \"200\",\n" +
                "  \"num_results\": 1,\n" +
                "  \"results\": [\n" +
                "    {\n" +
                "      \"list_name\": \"list name\",\n" +
                "      \"display_name\": \"display name\",\n" +
                "      \"list_name_encoded\": \"list name encoded\",\n" +
                "      \"oldest_published_date\": \"oldest published date\",\n" +
                "      \"newest_published_date\": \"newest published date\",\n" +
                "      \"updated\": \"updated\"\n" +
                "    }\n" +
                "  ]\n" +
                "}\n";

        BestSellerListName expectedResponse = objectMapper.readValue(expectedResponseBodyStr, BestSellerListName.class);

        ResponseEntity<String> mockResponseEntity = ResponseEntity.status(HttpStatus.OK).body(expectedResponseBodyStr);

        doReturn(new URI("http://test")).when(nytBookService).getNytNamesApiUri();

        doReturn(mockResponseEntity).when(nytBookService).callNYTsApi(new URI("http://test"));

        BestSellerListName result = nytBookService.getBestSellerNames();

        Assertions.assertThat(expectedResponse).isEqualTo(result);

    }

    /*
        If book list contains less than 20 record, all data will get with one api call (no need to call api with different offset)
    */
    @Test
    void shouldGetBookDetailsWithoutPagination() throws URISyntaxException, JsonProcessingException {
        String path1 = "/json/bookInfo_5.json";

        // upload data from bookInfo1
        BestSellerBooks expectedResult = jsonToBestSellerBookConverter.getJsonObject(path1);
        String bestSellerBooksStr = jsonToBestSellerBookConverter.getJsonString(path1);

        ResponseEntity<String> mockResponseEntity = ResponseEntity.status(HttpStatus.OK).body(bestSellerBooksStr);

        doReturn(new URI("http://test")).when(nytBookService).createBookDetailsNYTApiUri(anyString() , anyInt());

        doReturn(mockResponseEntity).when(nytBookService).callNYTsApi(new URI("http://test"));

        BestSellerBooks actualResult = nytBookService.getBooksDetailsByListNameFromNYT("paperback-advice");

        Assertions.assertThat(objectMapper.writeValueAsString(expectedResult)).isEqualTo(objectMapper.writeValueAsString(actualResult));

    }

    /*
        If book list contains more than 20 record, need to call api with other offsets
    */
    @Test
    void shouldGetBookDetailsWithPagination() throws URISyntaxException, JsonProcessingException {
        String path1 = "/json/bookInfo25_part1.json";
        // upload data from bookInfo1
        BestSellerBooks expectedResult1 = jsonToBestSellerBookConverter.getJsonObject(path1);
        String expectedResultStr1 = jsonToBestSellerBookConverter.getJsonString(path1);
        ResponseEntity<String> mockResponseEntity1 = ResponseEntity.status(HttpStatus.OK).body(expectedResultStr1);
        doReturn(new URI("http://test1")).when(nytBookService).createBookDetailsNYTApiUri("paperback-advice", 0);
        doReturn(mockResponseEntity1).when(nytBookService).callNYTsApi(new URI("http://test1"));


        String path2 = "/json/bookInfo25_part2.json";
        // upload data from bookInfo1
        BestSellerBooks expectedResult2 = jsonToBestSellerBookConverter.getJsonObject(path2);
        String expectedResultStr2 = jsonToBestSellerBookConverter.getJsonString(path2);
        ResponseEntity<String> mockResponseEntity2 = ResponseEntity.status(HttpStatus.OK).body(expectedResultStr2);
        doReturn(new URI("http://test2")).when(nytBookService).createBookDetailsNYTApiUri("paperback-advice", 20);
        doReturn(mockResponseEntity2).when(nytBookService).callNYTsApi(new URI("http://test2"));

        BestSellerBooks actualResult = nytBookService.getBooksDetailsByListNameFromNYT("paperback-advice");

        String path3 = "/json/bookInfo25_total.json";
        // upload data from bookInfo1
        BestSellerBooks expectedResult3= jsonToBestSellerBookConverter.getJsonObject(path3);

        Assertions.assertThat(objectMapper.writeValueAsString(expectedResult3)).isEqualTo(objectMapper.writeValueAsString(actualResult));

    }


    @Test
    void nytNamesApiUriShouldContainSpecificPath() {
        assertTrue(nytBookService.getNytNamesApiUri().getPath().contains("lists/names.json"));
    }

    @Test
    void nytBooksInfoApiUriShouldContainSpecificPath() {
        assertTrue(nytBookService.createBookDetailsNYTApiUri(anyString() , anyInt() ).getPath().contains("lists.json"));
    }

}