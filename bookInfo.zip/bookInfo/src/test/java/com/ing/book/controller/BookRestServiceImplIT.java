package com.ing.book.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class BookRestServiceImplIT {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void callGetBooksByAuthorNameShouldHaveSuccessStatus() {

        String endpoint = "/me/books/list?author=authorName";

        ResponseEntity<String> response = restTemplate.getForEntity(endpoint, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test
    public void callGetBooksByAuthorNameAndYear_ShouldHaveSuccessStatus() {

        String endpoint = "/me/books/list?author=authorName&year=2021";

        ResponseEntity<String> response = restTemplate.getForEntity(endpoint, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test
    public void callGetBooksByAuthorNameAndYear_ShouldHaveSuccessStatus_without_year_value() {

        String endpoint = "/me/books/list?author=authorName&year=";

        ResponseEntity<String> response = restTemplate.getForEntity(endpoint, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

}