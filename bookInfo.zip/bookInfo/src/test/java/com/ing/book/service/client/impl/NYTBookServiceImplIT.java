package com.ing.book.service.client.impl;

import com.ing.book.domain.BestSellerBooks;
import com.ing.book.domain.BestSellerListName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.Random;
import static org.junit.jupiter.api.Assertions.assertFalse;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class NYTBookServiceImplIT {

    @Autowired
    private NYTBookServiceImpl nytBookService;


    @Test
    void getBooksInfoByListName() {
        // Get bestSellerLists name
        BestSellerListName names = nytBookService.getBestSellerNames();
        assertFalse(names.getResults().isEmpty());
        //Generate a random number to get bestSeller book details for a random list
        int randomIndex = new Random().nextInt(names.getNum_results() + 1);

        BestSellerBooks books = nytBookService.getBooksDetailsByListNameFromNYT(names.getResults().get(randomIndex).getList_name_encoded());

        assertFalse(books.getResults().isEmpty());
    }
}