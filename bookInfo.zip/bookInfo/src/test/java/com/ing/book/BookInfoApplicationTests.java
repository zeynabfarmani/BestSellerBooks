package com.ing.book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BookInfoApplicationTests {

    private static final String[] ARGS = {};

    @Test
    public void contextLoadsTest() {
        BookInfoApplication.main(ARGS);
    }

}
