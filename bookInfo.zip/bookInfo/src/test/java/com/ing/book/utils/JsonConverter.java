package com.ing.book.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

public class JsonConverter<T> {
    private final Class<T> type;
    private final ObjectMapper objectMapper;

    public JsonConverter(Class<T> type, ObjectMapper objectMapper) {
        this.type = type;
        this.objectMapper = objectMapper;
    }

    public T getJsonObject(String path) {
        try {
            URL url = getClass().getResource(path);
            if (url == null) {
                return null;
            }

            String json = new String(Files.readAllBytes(Paths.get(url.toURI())));
            return objectMapper.readValue(json, type);
        } catch (IOException | java.net.URISyntaxException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getJsonString(String path){
        try {
            URL url = getClass().getResource(path);
            if (url == null) {
                return null;
            }
            return new String(Files.readAllBytes(Paths.get(url.toURI())));

        } catch (IOException | java.net.URISyntaxException e) {
            e.printStackTrace();
            return null;
        }
    }
}
