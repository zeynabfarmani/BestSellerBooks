package com.ing.book.service.client.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.book.domain.BestSellerBooks;
import com.ing.book.domain.BestSellerBookInfo;
import com.ing.book.domain.BestSellerListName;
import com.ing.book.exception.InternalServerErrorException;
import com.ing.book.exception.InvalidApiKeyException;
import com.ing.book.exception.NYTsApiCallException;
import com.ing.book.exception.NotFoundException;
import com.ing.book.exception.RateLimitExceedException;
import com.ing.book.service.client.BookServiceApi;
import com.ing.book.utils.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.List;

/**
 * The implementation of BookServiceApis for NewYorkTimes
 */
@Service
public class NYTBookServiceImpl implements BookServiceApi {
    private static final Logger logger = LoggerFactory.getLogger(NYTBookServiceImpl.class);
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${api.nyt.baseUrl}")
    private String baseUrl;

    @Value("${api.nyt.apiKey}")
    private String apiKey;

    @Override
    public BestSellerListName getBestSellerNames() throws RuntimeException{
        try {
            ResponseEntity<String> responseEntity = callNYTsApi(getNytNamesApiUri());
            if(responseEntity != null){
                return objectMapper.readValue(responseEntity.getBody(), BestSellerListName.class);
            } else
                return null;
        } catch (JsonProcessingException e) {
            logger.error("Exception in processing json response, error message: {}",e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /*
    Call NewYorkTimes api to get book information for a specific list

     */
    @Override
    public BestSellerBooks getBooksDetailsByListNameFromNYT(String listName) throws RuntimeException {
        try {
            // First api call is with offset = 0
            ResponseEntity<String> responseEntity = callNYTsApi(createBookDetailsNYTApiUri(listName, 0));
            if(responseEntity != null){

                BestSellerBooks books = objectMapper.readValue(responseEntity.getBody(), BestSellerBooks.class);

                return retrieveBookInfo(books, listName);
            } else
                return null;
        } catch (JsonProcessingException e) {
            logger.error("Exception in processing json response, error message: {}",e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /*
    Check data to see if the number of result is more than `20`, call api with next offsets (offset values is like 0,20,40,...)
     */
    public BestSellerBooks retrieveBookInfo(BestSellerBooks books, String listName) throws RuntimeException{
        if (books != null) {
            int numOfResult = books.getNum_results();
            if (numOfResult >= Constants.NYT_API_OFFSET) {
                int offset = 0;
                do {
                    offset += Constants.NYT_API_OFFSET;
                    List<BestSellerBookInfo> infos = this.getBooksInfoByListNameWithPagination(listName, offset);
                    if (!infos.isEmpty()) books.getResults().addAll(infos);
                    numOfResult-=offset;
                } while (offset < numOfResult);
            }
        }
        return books;
    }

/*
Call api with next offset value and return the book list to be added to the original list
 */
    public List<BestSellerBookInfo> getBooksInfoByListNameWithPagination(String name, int offset) throws RuntimeException {

        try {
            ResponseEntity<String> responseEntity = callNYTsApi(createBookDetailsNYTApiUri(name, offset));
            if (responseEntity != null) {
                BestSellerBooks books = objectMapper.readValue(responseEntity.getBody(), BestSellerBooks.class);
                return books.getResults();
            } else
                return Collections.emptyList();

        } catch (JsonProcessingException e) {
            logger.error("Exception in processing json response, error message: {}",e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /*
    Call NewYorkTimes api for the specified URI
     */
    public ResponseEntity<String> callNYTsApi(URI apiUri) throws RuntimeException{
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            RequestEntity<String> requestEntity = new RequestEntity<>(headers, HttpMethod.GET, apiUri);
            ResponseEntity<String> responseEntity = restTemplate.exchange(requestEntity, String.class);
            if(responseEntity.getStatusCode() == HttpStatusCode.valueOf(200))
                return responseEntity;
            else
                throw new NYTsApiCallException(Constants.NYT_API_CALL_ERROR);
        } catch (HttpClientErrorException e) {
            // Catch HttpClientErrorException and translate to custom exception based on the statusCode
            HttpStatusCode statusCode = e.getStatusCode();
            switch (statusCode.value()) {
                case 429:
                    throw new RateLimitExceedException(Constants.RATE_LIMIT_EXCEED);
                case 401:
                    logger.error("Invalid api key exception");
                    throw new InvalidApiKeyException(Constants.INVALID_API_KEY);
                case 404:
                    logger.error("Not found exception");
                    throw new NotFoundException(Constants.SERVICE_NOT_FOUND);
                case 500:
                    logger.error("internal server error");
                    throw new InternalServerErrorException(Constants.INTERNAL_SERVER_ERROR);
                default:
                    logger.error("exception , error:"+e.getMessage());
                }
            throw new NYTsApiCallException(Constants.NYT_API_CALL_ERROR);
        }catch (Exception e){
            System.out.println("error");
            throw new RuntimeException();
        }
    }

    public URI getNytNamesApiUri() {
        try {
            return new URI(baseUrl + "lists/names.json?&api-key=" + apiKey);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    public URI createBookDetailsNYTApiUri(String name, int offset) {
        try {
            return new URI(baseUrl + "lists.json?list=" + name + "&offset=" + offset + "&api-key=" + apiKey);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

}
