package com.ing.book.domain;

import lombok.Getter;
import lombok.Setter;
import java.util.List;


/**
 * Domain class for mapping details of bestSeller books in response of /lists.json api
 */
@Getter
@Setter
public class BestSellerBookInfo {
    private String list_name;
    private String display_name;
    private String bestsellers_date;
    private String published_date;
    private String rank;
    private String rank_last_week;
    private String weeks_on_list;
    private String asterisk;
    private String dagger;
    private String amazon_product_url;
    private List<ISBN> isbns;
    private List<BookDetail> book_details;
    private List<BookReview> reviews;

}
