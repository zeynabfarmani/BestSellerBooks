package com.ing.book.config;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.ing.book.domain.Book;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;


/**
 * CacheStore class, includes configuration and methods for add data and retrieve data from cache
 */
public class CacheStore {
    private final Cache<String, HashSet<Book>> cache;
    public CacheStore(int expiryDuration, TimeUnit timeUnit) {
        cache = CacheBuilder.newBuilder()
                .expireAfterWrite(expiryDuration, timeUnit)
                .concurrencyLevel(Runtime.getRuntime().availableProcessors())
                .build();
    }
    public void addToCache(String key, HashSet<Book> values) {
        cache.put(key, values);
    }

    public HashSet<Book> getFromCache(String key) {
        return cache.getIfPresent(key);
    }

    public boolean isExpired(String key) {
        return cache.getIfPresent(key) == null;
    }
}
