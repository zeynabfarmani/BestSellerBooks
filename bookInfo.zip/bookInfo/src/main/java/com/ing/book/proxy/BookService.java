package com.ing.book.proxy;

import com.ing.book.controller.DTO.BookListDTO;
import com.ing.book.domain.Book;

import java.net.URISyntaxException;
import java.util.List;

/**
 * Interface of BookServices
 */
public interface BookService {
    BookListDTO getBooksByAuthorAndYear(String authorName, List<Integer> years) throws URISyntaxException;

}
