package com.ing.book.utils;

public class Constants {
    public static final int NYT_API_OFFSET = 20;

    // Error messages
    public static final String INVALID_API_KEY = "ApiKey is not valid";
    public static final String RATE_LIMIT_EXCEED = "Api call rate Limit exceed";
    public static final String SERVICE_NOT_FOUND = "Api not found";
    public static final String NYT_API_CALL_ERROR = "Error in calling Nyts api";
    public static final String INTERNAL_SERVER_ERROR = "Internal server error";

}
