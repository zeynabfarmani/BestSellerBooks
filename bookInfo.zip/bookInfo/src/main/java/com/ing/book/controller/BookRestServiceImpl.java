package com.ing.book.controller;

import com.ing.book.controller.DTO.BookListDTO;
import com.ing.book.proxy.NYTBookServiceProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/me/books")
public class BookRestServiceImpl implements BookRestService{

    private static final Logger logger = LoggerFactory.getLogger(BookRestServiceImpl.class);

    private final NYTBookServiceProxy nytBookService;

    public BookRestServiceImpl(final NYTBookServiceProxy bookService) {
        this.nytBookService = bookService;
    }

    /**
     * Get books information of author for specified years.
     * Could pass multiple years, separated with `Comma`, to this method
     */
    @Override
    public ResponseEntity<BookListDTO> getBooksByAuthorAndYear(String authorName, String year) {
        try {
            List<Integer> years = Collections.emptyList();
            if (year != null) {
                if (!year.isEmpty()) {

                    logger.debug("Request books for author {} and year {}", authorName, year);

                    years = Arrays.stream(year.split(","))
                            .map(Integer::parseInt)
                            .collect(Collectors.toList());
                }
            }
            BookListDTO books = nytBookService.getBooksByAuthorAndYear(authorName, years);

            return ResponseEntity.ok(books);
        }catch (Exception e){
            logger.error("Exception occurred in calling endpoint",e.getMessage());
            return (ResponseEntity<BookListDTO>) ResponseEntity.internalServerError();
        }
    }

}
