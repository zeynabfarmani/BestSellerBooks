package com.ing.book.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Objects;

/**
 * Domain class for mapping response of /names.json api to get names of bestSellerList
 */
@Getter
@Setter
public class BestSellerListName {
    private String status;
    private String copyright;
    private int num_results;
    private List<ListNameInfo> results;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BestSellerListName names = (BestSellerListName) o;
        return num_results == names.num_results &&
                Objects.equals(status, names.status) &&
                Objects.equals(copyright, names.copyright) &&
                Objects.equals(results, names.results);
    }

    @Override
    public int hashCode() {
        return Objects.hash(status, copyright, num_results, results);
    }

}
