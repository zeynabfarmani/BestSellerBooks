package com.ing.book.controller.DTO;

import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import java.util.Objects;

/*
 * BookInfoDTO class represents the DTO used to create the book information
 * response for the endpoint
 */
@Setter
@Getter
public class BookInfoDTO implements Serializable {
    private String name;
    private String publisherName;
    private int publishYear;

    public BookInfoDTO(final String name,
                       final String publisherName,
                       final int publishYear){
        this.name = name;
        this.publisherName = publisherName;
        this.publishYear = publishYear;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BookInfoDTO book = (BookInfoDTO) o;
        return publishYear == book.publishYear &&
                Objects.equals(name, book.name) &&
                Objects.equals(publisherName, book.publisherName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, publisherName, publishYear);
    }
}
