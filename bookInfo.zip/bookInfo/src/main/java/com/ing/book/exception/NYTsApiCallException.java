package com.ing.book.exception;

public class NYTsApiCallException extends RuntimeException{
    public NYTsApiCallException(String message) {
        super(message);
    }

}
