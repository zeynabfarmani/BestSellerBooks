package com.ing.book.scheduler;

import com.ing.book.service.core.CacheUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Scheduler to retrieve data from NewYorkTimes api to update data in the cache.
 * This scheduler is running at fixedRate
 */
@Component
public class NYTScheduler {
     private static final Logger logger = LoggerFactory.getLogger(NYTScheduler.class);

    private final CacheUtils cacheUtils;

    public NYTScheduler(CacheUtils cacheUtils) {
        this.cacheUtils = cacheUtils;
    }

    @Scheduled(fixedDelayString = "${api.nyt.scheduler.period}")
     void updateCacheData() {
        logger.info("Refreshing cache data started");
        try {
            cacheUtils.retrieveDataFromNYTsApi();
        }catch (RuntimeException e){
            logger.error(e.getMessage());
        }
    }

}
