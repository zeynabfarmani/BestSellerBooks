package com.ing.book.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Domain class for mapping BookOverview of book detail in response of  /lists.json api
 */
@Getter
@Setter
public class BookDetail {
    private String title;
    private String description;
    private String contributor;
    private String author;
    private String contributor_note;
    private String price;
    private String age_group;
    private String publisher;
    private String primary_isbn13;
    private String primary_isbn10;

    public BookDetail(){}
    public BookDetail(String title,
                      String description,
                      String contributor,
                      String author,
                      String contributor_note,
                      String price,
                      String age_group,
                      String publisher,
                      String primary_isbn13,
                      String primary_isbn10){
        this.title = title;
        this.description = description;
        this.contributor = contributor;
        this.author = author;
        this.contributor_note = contributor_note;
        this.price = price;
        this.age_group = age_group;
        this.publisher = publisher;
        this.primary_isbn13 = primary_isbn13;
        this.primary_isbn10 = primary_isbn10;
    }
}
