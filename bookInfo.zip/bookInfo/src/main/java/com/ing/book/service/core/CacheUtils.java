package com.ing.book.service.core;

import com.ing.book.config.CacheStore;
import com.ing.book.domain.BestSellerBooks;
import com.ing.book.domain.BestSellerListName;
import com.ing.book.domain.Book;
import com.ing.book.domain.ListNameInfo;
import com.ing.book.exception.RateLimitExceedException;
import com.ing.book.service.client.impl.NYTBookServiceImpl;
import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.concurrent.Executor;

/**
 * CacheUtils contains some methods for updating data in cache
 */
@Component
public class CacheUtils {

    private final Logger logger = LoggerFactory.getLogger(CacheUtils.class);
    private final NYTBookServiceImpl nytBookService;
    private final Executor nytThreadPool;

    @Getter
    private final CacheStore booksInfoByAuthorCache;

    @Value("${api.nyt.thread.sleep}")
    private int threadSleep;

    public CacheUtils(NYTBookServiceImpl nytBookService,
                      @Qualifier("nytTaskExecutor") Executor nytThreadPool,
                      CacheStore booksInfoByAuthorCache) {
        this.nytBookService = nytBookService;
        this.nytThreadPool = nytThreadPool;
        this.booksInfoByAuthorCache = booksInfoByAuthorCache;
    }

    /**
     * Retrieve books data from NewYorkTimes api to update cache.
     */
    public void retrieveDataFromNYTsApi() throws RuntimeException {

        // Call NewYorkTimes api to get BestSellers name List
        BestSellerListName bestSellerNames = nytBookService.getBestSellerNames();

        if (bestSellerNames != null) {
            // Get information of books for each bestSellerList name
            for (ListNameInfo name : bestSellerNames.getResults()) {

                nytThreadPool.execute(() -> retrieveBookData(name.getList_name_encoded()));
            }
        }
    }

    public void retrieveBookData(String name) {
        try {
            // For calling /lists.json api of NewYorkTimes, encoded name of list should be used (based on NewYorkTimes api specification)
            getBooksDetailsByListName(name);
            logger.info("Data for list [{}] is retrieved", name);

        } catch (RateLimitExceedException e) {
           /*
            If there is RateLimitExceedException, retry after 12 seconds;
            otherwise for the other type of RuntimeExceptions like
            InvalidApiKeyException,InternalServerErrorException,NotFoundException,NYTsApiCallException
            the exception will be thrown and in scheduler the current thread will be stopped and start in the next window time(in this app scheduler is running every 3 minutes)
            */
            logger.debug("RateLimitExceedException in retrieving data for list [{}]", name);
            sleepForAWhile();
            retrieveBookData(name);
        }
    }

    /*
    Get information of books in a bestSeller list and collect data for cache
     */
    public void getBooksDetailsByListName(String name) throws RuntimeException {
        // Get books information in a list
        BestSellerBooks bestSellerBooks = nytBookService.getBooksDetailsByListNameFromNYT(name);

        //Gather books data in `Book` objects to add to the cache
        bestSellerBooks.getResults().forEach(bestSellerInfo ->
                bestSellerInfo.getBook_details().forEach(bookDetail -> {
                    Book book = new Book(
                            bookDetail.getTitle(),
                            bookDetail.getAuthor(),
                            bookDetail.getPublisher(),
                            extractYearFromPublishedDate(bestSellerInfo.getPublished_date())
                    );
                    addBookToAuthorList(book.getAuthor(), book, name);
                })
        );
    }

    /*
    Add `book` to the list of the books for `Author`
    */
    public void addBookToAuthorList(String author, Book book, String nameList) {
        // Using HashSet to prevent duplicate
        HashSet<Book> books = booksInfoByAuthorCache.getFromCache(author);
        if (books == null) {
            books = new HashSet<>();
        }
        books.add(book);
        booksInfoByAuthorCache.addToCache(author, books);
        logger.debug("Book [{}] , author [{}] from list[{}] is added to cache", book.getName(), book.getAuthor(), nameList);
    }

    /*
    Method for sleep thread
     */
    void sleepForAWhile() {
        try {
            Thread.sleep(threadSleep);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("InterruptedException, error message:{}", e.getMessage());
        }
    }

    /*
    Extract `Year` from `date` data
     */
    public int extractYearFromPublishedDate(String publishedDate) {
        return Integer.parseInt(publishedDate.substring(0, 4));
    }

}
