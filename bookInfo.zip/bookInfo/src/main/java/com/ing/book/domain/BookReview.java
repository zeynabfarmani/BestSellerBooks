package com.ing.book.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Domain class for mapping BookOverview of bestSeller books in response of  /lists.json api
 */
@Getter
@Setter
public class BookReview {
    private String book_review_link;
    private String first_chapter_link;
    private String sunday_review_link;
    private String article_chapter_link;
}
