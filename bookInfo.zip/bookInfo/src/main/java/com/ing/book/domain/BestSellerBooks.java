package com.ing.book.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Domain class for mapping response of /lists.json api to get bestSellerBooks of a list
 */
@Getter
@Setter
public class BestSellerBooks {
    private String status;
    private String copyright;
    private Integer num_results;
    private String last_modified;
    private List<BestSellerBookInfo> results;
}
