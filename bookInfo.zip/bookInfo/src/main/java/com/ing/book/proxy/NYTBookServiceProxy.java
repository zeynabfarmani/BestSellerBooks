package com.ing.book.proxy;

import com.ing.book.config.CacheStore;
import com.ing.book.controller.DTO.BookInfoDTO;
import com.ing.book.controller.DTO.BookListDTO;
import com.ing.book.domain.Book;
import org.springframework.stereotype.Component;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The NYTBookServiceProxy class, based on the proxy design pattern,
 * acts as a proxy between the application's API calls and the
 * New York Times (NYT) API.
 */
@Component
public class NYTBookServiceProxy implements BookService {

    private final CacheStore booksInfoByAuthorCache;

    public NYTBookServiceProxy(CacheStore booksInfoByAuthorCache) {
        this.booksInfoByAuthorCache = booksInfoByAuthorCache;
    }

    /**
     * Retrieve data from cache and map data to DTOs
     * @param authorName
     * @param years
     * @return BookListDTO
     */
    @Override
    public BookListDTO getBooksByAuthorAndYear(String authorName, List<Integer> years) {
        HashSet<Book> books = booksInfoByAuthorCache.getFromCache(authorName);
        if(books != null) {
            if(!years.isEmpty()) {
                List<BookInfoDTO> bookInfoDTOList = books.stream()
                        .filter(book -> years.contains(book.getPublishingYear()))
                        .map(book -> new BookInfoDTO(book.getName(), book.getPublisherName(), book.getPublishingYear()))
                        .collect(Collectors.toList());
                return new BookListDTO(authorName, bookInfoDTOList);
            }else{
                List<BookInfoDTO> bookInfoDTOList = books.stream()
                        .map(book -> new BookInfoDTO(book.getName(), book.getPublisherName(), book.getPublishingYear()))
                        .collect(Collectors.toList());
                return new BookListDTO(authorName, bookInfoDTOList);
            }
        }else
            return new BookListDTO(authorName, Collections.emptyList());

    }
}
