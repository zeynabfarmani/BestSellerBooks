package com.ing.book.service.client;

import com.ing.book.domain.BestSellerBooks;
import com.ing.book.domain.BestSellerListName;
import com.ing.book.exception.NYTsApiCallException;

import java.net.URISyntaxException;

/**
 * BookServiceApi interface
 */
public interface BookServiceApi {
    BestSellerListName getBestSellerNames() throws URISyntaxException;

    BestSellerBooks getBooksDetailsByListNameFromNYT(String listName) throws URISyntaxException, NYTsApiCallException;
}
