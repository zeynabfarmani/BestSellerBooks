package com.ing.book.domain;

import lombok.Getter;
import lombok.Setter;
import java.util.Objects;

/**
 * Domain class for adding books data to cache
 */
@Getter
@Setter
public class Book {
    private String name;
    private String author;
    private String publisherName;
    private int publishingYear;

    public Book(String name,
                String author,
                String publisherName,
                int publishingYear){
        this.name = name;
        this.author = author;
        this.publisherName = publisherName;
        this.publishingYear = publishingYear;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return publishingYear == book.publishingYear &&
                Objects.equals(name, book.name) &&
                Objects.equals(author, book.author) &&
                Objects.equals(publisherName, book.publisherName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, author, publisherName, publishingYear);
    }
}
