package com.ing.book.controller.DTO;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/*
 * BookListDTO class represents the DTO used to create the list of book's information
 * response for the endpoint
 */

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Getter
public class BookListDTO implements Serializable {
    private final String authorName;
    private final int numOfBooks;
    private final List<BookInfoDTO> bookInfoDTOS;

    public BookListDTO(final String authorName,
                       final List<BookInfoDTO> bookInfoDTOS){
        this.authorName = authorName;
        this.bookInfoDTOS = bookInfoDTOS;
        this.numOfBooks = bookInfoDTOS.size();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BookListDTO book = (BookListDTO) o;
        return numOfBooks == book.numOfBooks &&
                Objects.equals(authorName, book.authorName) &&
                Objects.equals(bookInfoDTOS, book.bookInfoDTOS);
    }

    @Override
    public int hashCode() {
        return Objects.hash(authorName, numOfBooks, bookInfoDTOS);
    }
}
