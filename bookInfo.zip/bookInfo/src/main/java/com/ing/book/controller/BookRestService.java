package com.ing.book.controller;

import com.ing.book.controller.DTO.BookListDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Tag(name = "Book Info Api")
public interface BookRestService {
    @GetMapping("/list")
    @Operation(
            summary = "Get books information for by author name",
            description = "Get books information for by author name and year. Author name is required but year is optional")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation"),
            @ApiResponse(responseCode = "500", description = "Failed operation")
    })
    ResponseEntity<BookListDTO> getBooksByAuthorAndYear(@RequestParam(value ="author") String author,
                                                        @RequestParam(value = "year",  required = false) String year);

}
