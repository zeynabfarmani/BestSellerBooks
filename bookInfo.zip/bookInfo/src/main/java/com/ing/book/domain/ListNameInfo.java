package com.ing.book.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

/**
 * Domain class for mapping details of bestSellerList names in  /names.json api
 */
@Getter
@Setter
public class ListNameInfo {
    private String list_name;
    private String display_name;
    private String list_name_encoded;
    private String oldest_published_date;
    private String newest_published_date;
    private String updated;

    public ListNameInfo() {
    }
    public ListNameInfo(String list_name,
                        String display_name,
                        String list_name_encoded,
                        String oldest_published_date,
                        String newest_published_date,
                        String updated){
        this.list_name = list_name;
        this.display_name = display_name;
        this.list_name_encoded = list_name_encoded;
        this.oldest_published_date = oldest_published_date;
        this.newest_published_date = newest_published_date;
        this.updated = updated;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ListNameInfo list = (ListNameInfo) o;
        return Objects.equals(list_name, list.list_name) &&
                Objects.equals(display_name, list.display_name) &&
                Objects.equals(list_name_encoded, list.list_name_encoded) &&
                Objects.equals(oldest_published_date, list.oldest_published_date) &&
                Objects.equals(newest_published_date, list.newest_published_date) &&
                Objects.equals(updated, list.updated);
    }

    @Override
    public int hashCode() {
        return Objects.hash(list_name, display_name, list_name_encoded, oldest_published_date, updated);
    }
}
