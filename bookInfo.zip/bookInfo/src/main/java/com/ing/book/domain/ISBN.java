package com.ing.book.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Domain class for mapping ISBN of bestSeller books in response of  /lists.json api
 */
@Getter
@Setter
public class ISBN {
    private String isbn10;
    private String isbn13;
}
