package com.ing.book.config;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/*
Thread pool config class
 */
@Configuration
@EnableScheduling
public class ThreadPoolConfig {

    @Value("${api.nyt.scheduler.numOfThreads}")
    private int numOfThreads;

    @Bean("nytTaskExecutor")
    public Executor productThreadPoolTaskExecutor() {
        ThreadFactory threadFactory = new ThreadFactoryBuilder()
                .setNameFormat(" scheduled-task-%d")
                .build();

        return Executors.newScheduledThreadPool(numOfThreads, threadFactory);
    }

}
